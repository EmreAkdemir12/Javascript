﻿function daralt() {
    document.getElementById("kutu").className = "dar";
}

function normal() {
    document.getElementById("kutu").className = "normal";
}

function genislet() {
    document.getElementById("kutu").className = "genis";
}