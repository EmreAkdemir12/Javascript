﻿function uzerimde() {
    document.getElementById("metin2").innerHTML = "Fare üzerimde";
}

function disarida() {
    document.getElementById("metin2").innerHTML = "Fare dışarıda";
}

function tiklandi() {
    document.getElementById("metin1").innerHTML = "Tıklandı";
}

function basildi() {
    document.getElementById("metin3").innerHTML = "Fare tuşuna basıldı";
}

function birakildi() {
    document.getElementById("metin3").innerHTML = "Fare tuşu bırakıldı";
}