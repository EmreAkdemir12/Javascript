﻿function stil(prm1, prm2) {
    document.getElementById("yazi").style.color = prm1;
    document.getElementById("yazi").style.backgroundColor = prm2;

}