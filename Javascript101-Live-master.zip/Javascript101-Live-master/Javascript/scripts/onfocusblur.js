﻿function kutuGiris() {
    if (document.form1.k1.value == "Ara...") {
        document.form1.k1.value = "";
    }
}

function kutuCikis() {
    if (document.form1.k1.value == "") {
        document.form1.k1.value = "Ara...";
    }
}